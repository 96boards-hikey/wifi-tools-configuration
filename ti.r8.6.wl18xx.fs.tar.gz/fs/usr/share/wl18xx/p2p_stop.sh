#!/bin/sh

wpa_cli -iwlan0 terminate
